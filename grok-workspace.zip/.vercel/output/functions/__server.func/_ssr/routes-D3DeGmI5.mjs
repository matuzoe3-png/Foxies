import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronRight, a as Trash2, b as ChartColumn, c as Presentation, d as Pencil, f as MapPin, g as ChevronUp, h as Download, l as Plus, m as LayoutGrid, n as UserRound, o as Search, p as Mail, r as Upload, s as Printer, t as X, u as Phone, v as ChevronLeft, y as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D3DeGmI5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SEED_COMPANY = {
	name: "Tu empresa",
	line: "Equipo y personas"
};
function person(id, data) {
	return {
		id,
		name: data.name,
		role: data.role,
		area: data.area,
		city: data.city,
		email: data.email,
		phone: data.phone,
		since: data.since,
		bio: data.bio,
		quote: data.quote,
		photo: "",
		stats: data.stats.map(([label, value], i) => ({
			id: `${id}-st${i}`,
			label,
			value
		})),
		skills: data.skills.map(([name, level], i) => ({
			id: `${id}-sk${i}`,
			name,
			level
		})),
		highlights: data.highlights
	};
}
var SEED_PEOPLE = [
	person("marina", {
		name: "Marina Soler",
		role: "Directora general",
		area: "Dirección",
		city: "Madrid",
		email: "marina@tuempresa.com",
		phone: "+34 600 110 201",
		since: "2016",
		bio: "Marca el rumbo del estudio y cuida la relación con las cuentas que definen el año. Viene de dos agencias de marca y prefiere las decisiones escritas a las reuniones largas.",
		quote: "Si no cabe en una ficha, todavía no está claro.",
		stats: [
			["Años", "10"],
			["Cuentas", "48"],
			["Equipo", "22"],
			["Sedes", "3"]
		],
		skills: [
			["Estrategia", 5],
			["Cuentas", 4],
			["Negociación", 4]
		],
		highlights: [
			"Abrió la oficina de Madrid",
			"Mentora del equipo junior",
			"Lleva el comité de clientes"
		]
	}),
	person("hugo", {
		name: "Hugo Beltrán",
		role: "Director de diseño",
		area: "Diseño",
		city: "Barcelona",
		email: "hugo@tuempresa.com",
		phone: "+34 600 110 202",
		since: "2018",
		bio: "Traduce el brief en un sistema visual que el resto del equipo puede usar sin preguntar. Obsesionado con el ritmo tipográfico y con que cada entrega se entienda impresa.",
		quote: "Una buena lámina ahorra tres correos.",
		stats: [
			["Piezas", "120"],
			["Premios", "6"],
			["Sistemas", "9"],
			["Años", "8"]
		],
		skills: [
			["Dirección de arte", 5],
			["Tipografía", 5],
			["Identidad", 4]
		],
		highlights: ["Autor del sistema visual actual", "Revisa cada póster antes de salir"]
	}),
	person("ines", {
		name: "Inés Calderón",
		role: "Jefa de operaciones",
		area: "Operaciones",
		city: "Valencia",
		email: "ines@tuempresa.com",
		phone: "+34 600 110 203",
		since: "2019",
		bio: "Hace que los plazos se cumplan sin apagar al equipo. Coordina producción, proveedores y el calendario de entregas de las tres sedes.",
		quote: "El orden también es una forma de cuidar.",
		stats: [
			["Proyectos", "64"],
			["A tiempo", "96%"],
			["Proveedores", "18"],
			["Años", "7"]
		],
		skills: [
			["Planificación", 5],
			["Proveedores", 4],
			["Procesos", 4]
		],
		highlights: ["Dueña del calendario semanal", "Montó el protocolo de entregas"]
	}),
	person("leo", {
		name: "Leo Navarro",
		role: "Comercial senior",
		area: "Comercial",
		city: "Sevilla",
		email: "leo@tuempresa.com",
		phone: "+34 600 110 204",
		since: "2020",
		bio: "Abre conversaciones y las deja en un brief que diseño puede ejecutar. Conoce el sector hotelero y el de alimentación mejor que nadie en la casa.",
		quote: "Vendo la claridad, no el PowerPoint.",
		stats: [
			["Pipeline", "1.2M"],
			["Cierres", "17"],
			["Sectores", "4"],
			["Años", "6"]
		],
		skills: [
			["Nuevo negocio", 5],
			["Briefs", 4],
			["Cuentas", 4]
		],
		highlights: ["Mayor cuenta del año pasado", "Enlace con hostelería"]
	}),
	person("amina", {
		name: "Amina Farouk",
		role: "Product manager",
		area: "Producto",
		city: "Málaga",
		email: "amina@tuempresa.com",
		phone: "+34 600 110 205",
		since: "2021",
		bio: "Ordena qué se construye y por qué. Trabaja entre diseño, comercial y el cliente para que la pieza digital no se despegue de la promesa.",
		quote: "Una prioridad clara vale más que diez ideas.",
		stats: [
			["Lanzamientos", "11"],
			["NPS", "72"],
			["Squads", "2"],
			["Años", "5"]
		],
		skills: [
			["Discovery", 5],
			["Roadmap", 4],
			["Research", 4]
		],
		highlights: ["Lanzó el portal de clientes", "Facilita la revisión quincenal"]
	}),
	person("tomas", {
		name: "Tomás Riera",
		role: "Responsable financiero",
		area: "Finanzas",
		city: "Bilbao",
		email: "tomas@tuempresa.com",
		phone: "+34 600 110 206",
		since: "2017",
		bio: "Cuida el margen sin convertir cada proyecto en una hoja imposible. Explica los números en el mismo idioma que usa el resto del estudio.",
		quote: "Un número solo sirve si alguien puede contarlo.",
		stats: [
			["Margen", "28%"],
			["Cierres", "9"],
			["Años", "9"],
			["Auditorías", "4"]
		],
		skills: [
			["Control", 5],
			["Previsión", 4],
			["Contratos", 3]
		],
		highlights: ["Cierre mensual en cinco días", "Modelo de rentabilidad por cuenta"]
	})
];
function uid() {
	return crypto.randomUUID();
}
function blankPerson() {
	return {
		id: uid(),
		name: "Nueva persona",
		role: "Puesto",
		area: "Equipo",
		city: "",
		email: "",
		phone: "",
		since: "",
		bio: "",
		quote: "",
		photo: "",
		stats: [
			{
				id: uid(),
				label: "Años",
				value: "—"
			},
			{
				id: uid(),
				label: "Proyectos",
				value: "—"
			},
			{
				id: uid(),
				label: "Equipo",
				value: "—"
			}
		],
		skills: [{
			id: uid(),
			name: "Habilidad",
			level: 3
		}],
		highlights: []
	};
}
function clip(value, max, fallback = "") {
	if (typeof value !== "string") return fallback;
	return value.slice(0, max);
}
function sanitizePerson(raw) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	const id = clip(row.id, 80);
	const name = clip(row.name, 120);
	if (!id || !name) return null;
	const statsRaw = Array.isArray(row.stats) ? row.stats : [];
	const skillsRaw = Array.isArray(row.skills) ? row.skills : [];
	const highlightsRaw = Array.isArray(row.highlights) ? row.highlights : [];
	const photo = clip(row.photo, 6e5);
	const safePhoto = photo.startsWith("data:image/") ? photo : "";
	return {
		id,
		name,
		role: clip(row.role, 120),
		area: clip(row.area, 80),
		city: clip(row.city, 80),
		email: clip(row.email, 160),
		phone: clip(row.phone, 40),
		since: clip(row.since, 40),
		bio: clip(row.bio, 1200),
		quote: clip(row.quote, 280),
		photo: safePhoto,
		stats: statsRaw.slice(0, 6).flatMap((item, i) => {
			if (!item || typeof item !== "object") return [];
			const stat = item;
			const label = clip(stat.label, 40);
			const value = clip(stat.value, 24);
			if (!label && !value) return [];
			return [{
				id: clip(stat.id, 80) || `${id}-st${i}`,
				label: label || "Dato",
				value: value || "—"
			}];
		}),
		skills: skillsRaw.slice(0, 8).flatMap((item, i) => {
			if (!item || typeof item !== "object") return [];
			const skill = item;
			const skillName = clip(skill.name, 40);
			if (!skillName) return [];
			const level = typeof skill.level === "number" ? Math.min(5, Math.max(1, Math.round(skill.level))) : 3;
			return [{
				id: clip(skill.id, 80) || `${id}-sk${i}`,
				name: skillName,
				level
			}];
		}),
		highlights: highlightsRaw.filter((item) => typeof item === "string").map((item) => item.slice(0, 160)).filter((item) => item.trim().length > 0).slice(0, 6)
	};
}
function sanitizeCompany(raw) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	const name = clip(row.name, 80);
	if (!name) return null;
	return {
		name,
		line: clip(row.line, 120, SEED_COMPANY.line)
	};
}
function visiblePeople(people, query, area) {
	const q = query.trim().toLowerCase();
	return people.filter((person) => {
		if (area && area !== "Todos" && person.area !== area) return false;
		if (!q) return true;
		return [
			person.name,
			person.role,
			person.area,
			person.city,
			person.bio,
			person.quote
		].join(" ").toLowerCase().includes(q);
	});
}
function compressPhoto(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo leer la foto."));
		reader.onload = () => {
			const img = new Image();
			img.onload = () => {
				const scale = Math.min(1, 720 / Math.max(img.width, img.height));
				const width = Math.max(1, Math.round(img.width * scale));
				const height = Math.max(1, Math.round(img.height * scale));
				const canvas = document.createElement("canvas");
				canvas.width = width;
				canvas.height = height;
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("No se pudo preparar la foto."));
					return;
				}
				ctx.drawImage(img, 0, 0, width, height);
				resolve(canvas.toDataURL("image/jpeg", .72));
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("Usa una foto JPG o PNG."));
			img.src = String(reader.result || "");
		};
		reader.readAsDataURL(file);
	});
}
function seedState() {
	return {
		company: SEED_COMPANY,
		people: SEED_PEOPLE,
		selectedId: SEED_PEOPLE[0].id,
		hintDismissed: false
	};
}
var useStudio = create()(persist((set) => ({
	...seedState(),
	view: "muro",
	editing: false,
	query: "",
	area: "Todos",
	setView: (view) => set((state) => ({
		view,
		editing: view === "presentacion" ? false : state.editing
	})),
	setEditing: (editing) => set({ editing }),
	setQuery: (query) => set({ query }),
	setArea: (area) => set({ area }),
	select: (id) => set({ selectedId: id }),
	dismissHint: () => set({ hintDismissed: true }),
	setCompany: (patch) => set((state) => ({ company: {
		...state.company,
		...patch
	} })),
	updatePerson: (id, recipe) => set((state) => ({ people: state.people.map((person) => person.id === id ? recipe(person) : person) })),
	addPerson: () => {
		const person = blankPerson();
		set((state) => ({
			people: [...state.people, person],
			selectedId: person.id,
			editing: true,
			view: state.view === "presentacion" ? "ficha" : state.view
		}));
	},
	removePerson: (id) => set((state) => {
		const people = state.people.filter((person) => person.id !== id);
		return {
			people,
			selectedId: state.selectedId === id ? people[0]?.id ?? "" : state.selectedId
		};
	}),
	movePerson: (id, dir) => set((state) => {
		const index = state.people.findIndex((person) => person.id === id);
		const next = index + dir;
		if (index < 0 || next < 0 || next >= state.people.length) return state;
		const people = state.people.slice();
		const [item] = people.splice(index, 1);
		people.splice(next, 0, item);
		return { people };
	}),
	replaceAll: (company, people) => set({
		company,
		people,
		selectedId: people[0]?.id ?? "",
		editing: true,
		view: "muro"
	}),
	resetExamples: () => set({
		...seedState(),
		view: "muro",
		editing: true,
		query: "",
		area: "Todos"
	})
}), {
	name: "lamina-v1",
	skipHydration: true,
	partialize: (state) => ({
		company: state.company,
		people: state.people,
		selectedId: state.selectedId,
		hintDismissed: state.hintDismissed
	}),
	merge: (persisted, current) => {
		const data = persisted ?? {};
		const people = Array.isArray(data.people) ? data.people.map(sanitizePerson).filter((person) => person !== null).slice(0, 40) : [];
		if (people.length === 0) return current;
		const company = sanitizeCompany(data.company) ?? current.company;
		const selectedId = people.some((person) => person.id === data.selectedId) ? data.selectedId : people[0].id;
		return {
			...current,
			company,
			people,
			selectedId,
			hintDismissed: Boolean(data.hintDismissed)
		};
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Portrait({ person, className, letterClassName }) {
	const [broken, setBroken] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setBroken(false), [person.photo]);
	const letter = (person.name.trim().charAt(0) || "?").toUpperCase();
	if (person.photo && !broken) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: person.photo,
		alt: person.name,
		className: cn("h-full w-full object-cover", className),
		onError: () => setBroken(true)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-full w-full items-center justify-center bg-deep text-deep-fg", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display text-7xl italic leading-none", letterClassName),
			children: letter
		})
	});
}
function indexLabel(index, total) {
	return `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`;
}
var fieldClass = "min-h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none";
function Field({ label, value, onChange, multiline }) {
	const id = label.toLowerCase().replace(/\s+/g, "-");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-sm",
		htmlFor: id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), multiline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			id,
			value,
			rows: 4,
			onChange: (event) => onChange(event.target.value),
			className: `${fieldClass} py-2`
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			value,
			onChange: (event) => onChange(event.target.value),
			className: fieldClass
		})]
	});
}
function Editor({ onClose }) {
	const company = useStudio((state) => state.company);
	const people = useStudio((state) => state.people);
	const selectedId = useStudio((state) => state.selectedId);
	const setCompany = useStudio((state) => state.setCompany);
	const updatePerson = useStudio((state) => state.updatePerson);
	const addPerson = useStudio((state) => state.addPerson);
	const removePerson = useStudio((state) => state.removePerson);
	const movePerson = useStudio((state) => state.movePerson);
	const select = useStudio((state) => state.select);
	const replaceAll = useStudio((state) => state.replaceAll);
	const resetExamples = useStudio((state) => state.resetExamples);
	const person = people.find((item) => item.id === selectedId);
	const fileRef = (0, import_react.useRef)(null);
	const importRef = (0, import_react.useRef)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	function patch(recipe) {
		if (!person) return;
		updatePerson(person.id, recipe);
	}
	async function onPhoto(file) {
		if (!file || !person) return;
		setError("");
		try {
			const data = await compressPhoto(file);
			if (people.reduce((sum, item) => sum + (item.id === person.id ? 0 : item.photo.length), 0) + data.length > 38e5) {
				setError("No cabe otra foto tan grande. Quita alguna o usa una más pequeña.");
				return;
			}
			patch((current) => ({
				...current,
				photo: data
			}));
		} catch (cause) {
			setError(cause instanceof Error ? cause.message : "No se pudo guardar la foto.");
		}
	}
	function exportFile() {
		const blob = new Blob([JSON.stringify({
			company,
			people
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "lamina-equipo.json";
		link.click();
		URL.revokeObjectURL(url);
	}
	async function importFile(file) {
		if (!file) return;
		setError("");
		try {
			const parsed = JSON.parse(await file.text());
			const nextPeople = Array.isArray(parsed.people) ? parsed.people.map(sanitizePerson).filter((item) => item !== null).slice(0, 40) : [];
			const nextCompany = sanitizeCompany(parsed.company) ?? company;
			if (nextPeople.length === 0) {
				setError("Ese archivo no tiene personas válidas.");
				return;
			}
			replaceAll(nextCompany, nextPeople);
		} catch {
			setError("No se pudo leer el archivo. Tiene que ser el JSON exportado desde Lámina.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print fixed inset-0 z-40 flex justify-end bg-ink/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Cerrar editor",
			className: "hidden flex-1 sm:block",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex h-full w-full max-w-md flex-col bg-surface text-ink shadow-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Editar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Se guarda en este navegador."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "Cerrar",
					className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col gap-6 overflow-y-auto px-4 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Empresa"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nombre",
								value: company.name,
								onChange: (name) => setCompany({ name })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Línea",
								value: company.line,
								onChange: (line) => setCompany({ line })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Personas"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: addPerson,
								className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm text-accent-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Añadir"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									"aria-label": "Elegir persona",
									value: person?.id ?? "",
									onChange: (event) => {
										setConfirmDelete(false);
										select(event.target.value);
									},
									className: fieldClass,
									children: [people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Sin personas"
									}) : null, people.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: item.id,
										children: [
											String(index + 1).padStart(2, "0"),
											" · ",
											item.name
										]
									}, item.id))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Subir en el orden",
									disabled: !person,
									onClick: () => person && movePerson(person.id, -1),
									className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Bajar en el orden",
									disabled: !person,
									onClick: () => person && movePerson(person.id, 1),
									className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
								})
							]
						})]
					}),
					person ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-20 overflow-hidden rounded-full",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
											person,
											letterClassName: "text-3xl"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => fileRef.current?.click(),
											className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-4 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
												className: "size-4",
												"aria-hidden": "true"
											}), "Subir foto"]
										}), person.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => patch((current) => ({
												...current,
												photo: ""
											})),
											className: "text-left text-sm text-muted",
											children: "Quitar foto"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: "Sin foto se muestra la inicial."
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: fileRef,
										type: "file",
										accept: "image/jpeg,image/png,image/webp",
										className: "hidden",
										onChange: (event) => {
											onPhoto(event.target.files?.[0]);
											event.target.value = "";
										}
									})
								]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-accent",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nombre de la persona",
								value: person.name,
								onChange: (name) => patch((p) => ({
									...p,
									name
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Puesto",
								value: person.role,
								onChange: (role) => patch((p) => ({
									...p,
									role
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Área",
									value: person.area,
									onChange: (area) => patch((p) => ({
										...p,
										area
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Ciudad",
									value: person.city,
									onChange: (city) => patch((p) => ({
										...p,
										city
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Correo",
									value: person.email,
									onChange: (email) => patch((p) => ({
										...p,
										email
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Teléfono",
									value: person.phone,
									onChange: (phone) => patch((p) => ({
										...p,
										phone
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "En la empresa desde",
								value: person.since,
								onChange: (since) => patch((p) => ({
									...p,
									since
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Biografía",
								value: person.bio,
								multiline: true,
								onChange: (bio) => patch((p) => ({
									...p,
									bio
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Frase",
								value: person.quote,
								onChange: (quote) => patch((p) => ({
									...p,
									quote
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "Datos del póster"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: person.stats.length >= 4,
										onClick: () => patch((current) => ({
											...current,
											stats: [...current.stats, {
												id: crypto.randomUUID(),
												label: "Dato",
												value: "—"
											}]
										})),
										className: "min-h-11 text-sm text-accent disabled:opacity-40",
										children: "Añadir dato"
									})]
								}), person.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[1fr_5rem_auto] gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											"aria-label": "Etiqueta del dato",
											value: stat.label,
											onChange: (event) => patch((current) => ({
												...current,
												stats: current.stats.map((item) => item.id === stat.id ? {
													...item,
													label: event.target.value
												} : item)
											})),
											className: fieldClass
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											"aria-label": "Valor del dato",
											value: stat.value,
											onChange: (event) => patch((current) => ({
												...current,
												stats: current.stats.map((item) => item.id === stat.id ? {
													...item,
													value: event.target.value
												} : item)
											})),
											className: fieldClass
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Quitar dato",
											onClick: () => patch((current) => ({
												...current,
												stats: current.stats.filter((item) => item.id !== stat.id)
											})),
											className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
										})
									]
								}, stat.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "Habilidades"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: person.skills.length >= 6,
										onClick: () => patch((current) => ({
											...current,
											skills: [...current.skills, {
												id: crypto.randomUUID(),
												name: "Habilidad",
												level: 3
											}]
										})),
										className: "min-h-11 text-sm text-accent disabled:opacity-40",
										children: "Añadir"
									})]
								}), person.skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 rounded-xl border border-line p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											"aria-label": "Nombre de la habilidad",
											value: skill.name,
											onChange: (event) => patch((current) => ({
												...current,
												skills: current.skills.map((item) => item.id === skill.id ? {
													...item,
													name: event.target.value
												} : item)
											})),
											className: fieldClass
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Quitar habilidad",
											onClick: () => patch((current) => ({
												...current,
												skills: current.skills.filter((item) => item.id !== skill.id)
											})),
											className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex gap-1",
										role: "group",
										"aria-label": `Nivel de ${skill.name}`,
										children: [
											1,
											2,
											3,
											4,
											5
										].map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": skill.level === level,
											onClick: () => patch((current) => ({
												...current,
												skills: current.skills.map((item) => item.id === skill.id ? {
													...item,
													level
												} : item)
											})),
											className: level <= skill.level ? "min-h-11 flex-1 rounded-lg bg-ink text-sm text-deep-fg" : "min-h-11 flex-1 rounded-lg border border-line text-sm text-muted",
											children: level
										}, level))
									})]
								}, skill.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "Señales"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: person.highlights.length >= 5,
										onClick: () => patch((current) => ({
											...current,
											highlights: [...current.highlights, ""]
										})),
										className: "min-h-11 text-sm text-accent disabled:opacity-40",
										children: "Añadir"
									})]
								}), person.highlights.map((highlight, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										"aria-label": `Señal ${index + 1}`,
										value: highlight,
										onChange: (event) => patch((current) => ({
											...current,
											highlights: current.highlights.map((item, itemIndex) => itemIndex === index ? event.target.value : item)
										})),
										className: fieldClass
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Quitar señal",
										onClick: () => patch((current) => ({
											...current,
											highlights: current.highlights.filter((_, itemIndex) => itemIndex !== index)
										})),
										className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
									})]
								}, `${person.id}-h${index}`))]
							}),
							confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2 rounded-xl border border-line bg-paper p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										"¿Eliminar a ",
										person.name,
										"?"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											removePerson(person.id);
											setConfirmDelete(false);
										},
										className: "min-h-11 flex-1 rounded-full bg-accent text-sm text-accent-ink",
										children: "Eliminar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmDelete(false),
										className: "min-h-11 flex-1 rounded-full border border-line text-sm",
										children: "Cancelar"
									})]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setConfirmDelete(true),
								className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-line text-sm text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Eliminar persona"]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Añade a alguien para empezar la ficha."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-2 border-t border-line pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Copia de seguridad"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Exporta el equipo si vas a cambiar de navegador. La importación sustituye lo que hay ahora."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: exportFile,
										className: "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
											className: "size-4",
											"aria-hidden": "true"
										}), "Exportar"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => importRef.current?.click(),
										className: "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
											className: "size-4",
											"aria-hidden": "true"
										}), "Importar"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: importRef,
										type: "file",
										accept: "application/json",
										className: "hidden",
										onChange: (event) => {
											importFile(event.target.files?.[0]);
											event.target.value = "";
										}
									})
								]
							}),
							confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										"Esto borra tus cambios y vuelve al equipo de ejemplo de ",
										SEED_COMPANY.name,
										"."
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											resetExamples();
											setConfirmReset(false);
										},
										className: "min-h-11 flex-1 rounded-full bg-ink text-sm text-deep-fg",
										children: "Restaurar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmReset(false),
										className: "min-h-11 flex-1 rounded-full border border-line text-sm",
										children: "Cancelar"
									})]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setConfirmReset(true),
								className: "min-h-11 text-left text-sm text-muted",
								children: "Restaurar ejemplos"
							})
						]
					})
				]
			})]
		})]
	});
}
function initialsRow(people, selectedId, onSelect) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap justify-center gap-2",
		children: people.map((person, index) => {
			const active = person.id === selectedId;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onSelect(person.id),
				"aria-label": person.name,
				"aria-current": active ? "true" : void 0,
				className: active ? "flex min-h-11 min-w-11 items-center justify-center rounded-full bg-accent px-3 text-sm text-accent-ink" : "flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line bg-surface px-3 text-sm text-ink",
				children: String(index + 1).padStart(2, "0")
			}, person.id);
		})
	});
}
function Muro({ people, onOpen }) {
	if (people.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted",
		children: "Nadie coincide con la búsqueda. Prueba otro nombre o área."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3",
		children: people.map((person, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(person.id),
			className: "flex h-full w-full flex-col overflow-hidden rounded-card border border-line bg-surface text-left transition duration-200 hover:-translate-y-0.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-4/5 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					person,
					className: "absolute inset-0"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 left-3 rounded-full bg-paper px-2.5 py-1 text-xs text-ink tabular-nums",
					children: String(index + 1).padStart(2, "0")
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col gap-1 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl leading-tight text-ink",
						children: person.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: person.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs tracking-widest text-accent uppercase",
						children: person.area
					})
				]
			})]
		}) }, person.id))
	});
}
function Contact({ person }) {
	const items = [
		person.city ? {
			icon: MapPin,
			text: person.city
		} : null,
		person.email ? {
			icon: Mail,
			text: person.email
		} : null,
		person.phone ? {
			icon: Phone,
			text: person.phone
		} : null
	].filter((item) => item !== null);
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2 text-sm text-muted",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
				className: "size-4 shrink-0",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "break-all",
				children: item.text
			})]
		}, item.text))
	});
}
function Stats({ person }) {
	if (person.stats.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
		className: "grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-4",
		children: person.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-paper px-3 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs tracking-widest text-muted uppercase",
				children: stat.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "font-display text-3xl text-ink tabular-nums",
				children: stat.value
			})]
		}, stat.id))
	});
}
function Skills({ person }) {
	if (person.skills.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-3",
		children: person.skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-baseline justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: skill.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted tabular-nums",
				children: [skill.level, "/5"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1.5 overflow-hidden rounded-full bg-line",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-ink",
				style: { width: `${skill.level / 5 * 100}%` }
			})
		})] }, skill.id))
	});
}
function Highlights({ person }) {
	const items = person.highlights.filter((item) => item.trim());
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-2",
		children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-accent tabular-nums",
				children: String(index + 1).padStart(2, "0")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
		}, `${item}-${index}`))
	});
}
function SheetNav({ index, total, onStep }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print flex items-center justify-between gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onStep(-1),
				className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					"aria-hidden": "true"
				}), "Anterior"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted tabular-nums",
				children: index >= 0 ? indexLabel(index, total) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onStep(1),
				className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm",
				children: ["Siguiente", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-4",
					"aria-hidden": "true"
				})]
			})
		]
	});
}
function Ficha({ person, companyName, index, total, onStep }) {
	if (!person) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted",
		children: "No hay nadie en esta vista. Añade una persona o limpia el filtro."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "print-sheet overflow-hidden rounded-card border border-line bg-surface md:grid md:grid-cols-[minmax(0,0.86fr)_minmax(0,1.14fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-80",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					person,
					className: "absolute inset-0",
					letterClassName: "text-8xl md:text-9xl"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-6 p-6 md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-accent uppercase",
							children: companyName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => window.print(),
							className: "no-print inline-flex min-h-11 items-center gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Imprimir"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: person.area
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-5xl leading-none text-ink",
							children: person.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-lg text-muted",
							children: [person.role, person.since ? ` · desde ${person.since}` : ""]
						})
					] }),
					person.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-prose text-base leading-relaxed",
						children: person.bio
					}) : null,
					person.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "border-l-2 border-accent pl-4 font-display text-2xl italic leading-snug",
						children: person.quote
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { person }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, { person })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetNav, {
			index,
			total,
			onStep
		})]
	});
}
function Infografia({ person, companyName, index, total, onStep }) {
	if (!person) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted",
		children: "No hay nadie para componer el póster."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			className: "print-sheet overflow-hidden rounded-card border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-2 shrink-0 bg-accent",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col gap-8 p-5 sm:p-8 md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 text-xs tracking-widest uppercase",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: companyName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-ink tabular-nums",
								children: index >= 0 ? indexLabel(index, total) : ""
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid items-start gap-8 md:grid-cols-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "order-2 flex flex-col gap-6 md:order-1 md:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-widest text-accent uppercase",
											children: person.area
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-5xl leading-none text-ink sm:text-6xl",
											children: person.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-lg text-muted",
											children: person.role
										})
									] }),
									person.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-prose leading-relaxed",
										children: person.bio
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { person })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "order-1 md:order-2 md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "aspect-square overflow-hidden rounded-card",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
										person,
										letterClassName: "text-8xl"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, { person })
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-8 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mb-3 text-xs tracking-widest text-muted uppercase",
								children: "Oficio"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skills, { person })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mb-3 text-xs tracking-widest text-muted uppercase",
								children: "Señales"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlights, { person })] })]
						}),
						person.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "font-display text-3xl italic leading-snug text-ink",
							children: [
								"“",
								person.quote,
								"”"
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 border-t border-line pt-4 text-xs tracking-widest text-muted uppercase",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lámina" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => window.print(),
								className: "no-print inline-flex min-h-11 items-center gap-2 normal-case",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Imprimir póster"]
							})]
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetNav, {
			index,
			total,
			onStep
		})]
	});
}
function Presentacion({ people, person, companyName, onStep, onSelect, onExit }) {
	if (!person) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-deep px-6 text-center text-deep-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No hay personas para presentar." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onExit,
			className: "min-h-11 rounded-full bg-accent px-5 text-accent-ink",
			children: "Volver"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-30 flex flex-col bg-deep text-deep-fg",
		onTouchStart: (event) => {
			event.currentTarget.dataset.x = String(event.changedTouches[0]?.clientX ?? 0);
		},
		onTouchEnd: (event) => {
			const start = Number(event.currentTarget.dataset.x || 0);
			const dx = (event.changedTouches[0]?.clientX ?? 0) - start;
			if (dx > 48) onStep(-1);
			if (dx < -48) onStep(1);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3 px-4 py-3 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "Lámina"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-deep-muted",
						children: companyName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onExit,
						className: "min-h-11 rounded-full border border-deep-muted px-4 text-sm text-deep-fg",
						children: "Salir"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center gap-8 overflow-y-auto px-5 py-6 md:flex-row md:gap-16 md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-56 shrink-0 overflow-hidden rounded-full sm:size-72 md:size-96",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						person,
						letterClassName: "text-8xl"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xl text-center md:text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-accent uppercase",
							children: person.area
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl leading-none sm:text-6xl md:text-7xl",
							children: person.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xl text-deep-muted",
							children: person.role
						}),
						person.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-2xl italic leading-snug text-deep-fg",
							children: person.quote
						}) : null,
						person.stats.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-8 grid grid-cols-3 gap-4",
							children: person.stats.slice(0, 3).map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-deep-muted uppercase",
								children: stat.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-3xl tabular-nums",
								children: stat.value
							})] }, stat.id))
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex flex-col items-center gap-4 px-4 pt-2 pb-6",
				children: [initialsRow(people, person.id, onSelect), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Persona anterior",
						onClick: () => onStep(-1),
						className: "inline-flex size-11 items-center justify-center rounded-full border border-deep-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Persona siguiente",
						onClick: () => onStep(1),
						className: "inline-flex size-11 items-center justify-center rounded-full bg-accent text-accent-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					})]
				})]
			})
		]
	});
}
var VIEWS = [
	{
		id: "muro",
		label: "Muro",
		icon: LayoutGrid
	},
	{
		id: "ficha",
		label: "Ficha",
		icon: UserRound
	},
	{
		id: "infografia",
		label: "Póster",
		icon: ChartColumn
	},
	{
		id: "presentacion",
		label: "Presentar",
		icon: Presentation
	}
];
function StudioApp() {
	const company = useStudio((state) => state.company);
	const people = useStudio((state) => state.people);
	const selectedId = useStudio((state) => state.selectedId);
	const hintDismissed = useStudio((state) => state.hintDismissed);
	const view = useStudio((state) => state.view);
	const editing = useStudio((state) => state.editing);
	const query = useStudio((state) => state.query);
	const area = useStudio((state) => state.area);
	const setView = useStudio((state) => state.setView);
	const setEditing = useStudio((state) => state.setEditing);
	const setQuery = useStudio((state) => state.setQuery);
	const setArea = useStudio((state) => state.setArea);
	const select = useStudio((state) => state.select);
	const dismissHint = useStudio((state) => state.dismissHint);
	(0, import_react.useEffect)(() => {
		useStudio.persist.rehydrate();
	}, []);
	const areas = ["Todos", ...Array.from(new Set(people.map((person) => person.area).filter(Boolean)))];
	const activeArea = areas.includes(area) ? area : "Todos";
	const filtered = visiblePeople(people, query, activeArea);
	const deck = view === "presentacion" ? people : filtered;
	const person = deck.find((item) => item.id === selectedId) ?? deck[0];
	const index = person ? deck.findIndex((item) => item.id === person.id) : -1;
	function step(dir) {
		if (deck.length === 0) return;
		const next = (Math.max(0, index) + dir + deck.length) % deck.length;
		select(deck[next].id);
	}
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			if (target instanceof HTMLElement) {
				const tag = target.tagName;
				if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable) return;
			}
			if (view !== "presentacion" && view !== "ficha" && view !== "infografia") return;
			if (event.key === "ArrowRight") step(1);
			if (event.key === "ArrowLeft") step(-1);
			if (event.key === "Escape" && view === "presentacion") setView("muro");
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	if (view === "presentacion") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presentacion, {
		people,
		person: people.find((item) => item.id === selectedId) ?? people[0],
		companyName: company.name,
		onStep: (dir) => {
			if (people.length === 0) return;
			const next = (Math.max(0, people.findIndex((item) => item.id === selectedId)) + dir + people.length) % people.length;
			select(people[next].id);
		},
		onSelect: select,
		onExit: () => setView("muro")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-20 border-b border-line bg-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-none",
							children: "Lámina"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm text-muted",
							children: [company.name, company.line ? ` · ${company.line}` : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setEditing(!editing),
						className: editing ? "inline-flex min-h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm text-deep-fg" : "inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm text-accent-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
							className: "size-4",
							"aria-hidden": "true"
						}), editing ? "Cerrar" : "Editar"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex w-full max-w-6xl gap-1 overflow-x-auto px-4 pb-3",
					children: VIEWS.map((item) => {
						const Icon = item.icon;
						const active = view === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setView(item.id),
							"aria-pressed": active,
							className: active ? "inline-flex min-h-11 shrink-0 items-center justify-center gap-1.5 rounded-full bg-ink px-3 text-sm text-deep-fg" : "inline-flex min-h-11 shrink-0 items-center justify-center gap-1.5 rounded-full px-3 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4 shrink-0",
								"aria-hidden": "true"
							}), item.label]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-6xl flex-col gap-5 px-4 py-5",
				children: [
					!hintDismissed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "no-print flex items-start justify-between gap-3 rounded-xl border border-line bg-surface px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "Estos seis perfiles son de ejemplo. Edita el nombre de tu empresa, cambia los datos, sube fotos o bórralos y crea los de tu equipo. Todo queda guardado en este navegador."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: dismissHint,
							"aria-label": "Ocultar aviso",
							className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}) : null,
					view === "muro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "no-print flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Buscar por nombre, puesto o ciudad",
									"aria-label": "Buscar personas",
									className: "min-h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 overflow-x-auto pb-1",
								children: areas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setArea(item),
									className: activeArea === item ? "min-h-11 shrink-0 rounded-full bg-ink px-4 text-sm text-deep-fg" : "min-h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm",
									children: item
								}, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted tabular-nums",
								children: [
									filtered.length,
									" ",
									filtered.length === 1 ? "persona" : "personas"
								]
							})
						]
					}) : null,
					view === "muro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Muro, {
						people: filtered,
						onOpen: (id) => {
							select(id);
							setView("ficha");
						}
					}) : null,
					view === "ficha" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ficha, {
						person,
						companyName: company.name,
						index,
						total: deck.length,
						onStep: step
					}) : null,
					view === "infografia" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Infografia, {
						person,
						companyName: company.name,
						index,
						total: deck.length,
						onStep: step
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "no-print pb-4 text-center text-xs text-muted",
						children: "Los cambios viven en este navegador. En Editar puedes exportar una copia."
					})
				]
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, { onClose: () => setEditing(false) }) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };
