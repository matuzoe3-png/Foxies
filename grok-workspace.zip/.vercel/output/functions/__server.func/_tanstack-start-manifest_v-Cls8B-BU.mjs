//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cls8B-BU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Dmip1jC4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dmip1jC4.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CToxqmat.js"]
	}
} });
//#endregion
export { tsrStartManifest };
