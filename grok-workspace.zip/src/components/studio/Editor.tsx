import { useRef, useState } from "react";
import { ChevronDown, ChevronUp, Download, Plus, Trash2, Upload, X } from "lucide-react";
import {
  SEED_COMPANY,
  compressPhoto,
  sanitizeCompany,
  sanitizePerson,
  type Person,
} from "@/lib/people";
import { useStudio } from "@/lib/studio-store";
import { Portrait } from "@/components/studio/Portrait";

const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none";

function Field({
  label,
  value,
  onChange,
  multiline,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  multiline?: boolean;
}) {
  const id = label.toLowerCase().replace(/\s+/g, "-");
  return (
    <label className="flex flex-col gap-1 text-sm" htmlFor={id}>
      <span className="text-muted">{label}</span>
      {multiline ? (
        <textarea
          id={id}
          value={value}
          rows={4}
          onChange={(event) => onChange(event.target.value)}
          className={`${fieldClass} py-2`}
        />
      ) : (
        <input id={id} value={value} onChange={(event) => onChange(event.target.value)} className={fieldClass} />
      )}
    </label>
  );
}

export function Editor({ onClose }: { onClose: () => void }) {
  const company = useStudio((state) => state.company);
  const people = useStudio((state) => state.people);
  const selectedId = useStudio((state) => state.selectedId);
  const setCompany = useStudio((state) => state.setCompany);
  const updatePerson = useStudio((state) => state.updatePerson);
  const addPerson = useStudio((state) => state.addPerson);
  const removePerson = useStudio((state) => state.removePerson);
  const movePerson = useStudio((state) => state.movePerson);
  const select = useStudio((state) => state.select);
  const replaceAll = useStudio((state) => state.replaceAll);
  const resetExamples = useStudio((state) => state.resetExamples);
  const person = people.find((item) => item.id === selectedId);
  const fileRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  function patch(recipe: (current: Person) => Person) {
    if (!person) return;
    updatePerson(person.id, recipe);
  }

  async function onPhoto(file: File | undefined) {
    if (!file || !person) return;
    setError("");
    try {
      const data = await compressPhoto(file);
      const others = people.reduce((sum, item) => sum + (item.id === person.id ? 0 : item.photo.length), 0);
      if (others + data.length > 3_800_000) {
        setError("No cabe otra foto tan grande. Quita alguna o usa una más pequeña.");
        return;
      }
      patch((current) => ({ ...current, photo: data }));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo guardar la foto.");
    }
  }

  function exportFile() {
    const blob = new Blob([JSON.stringify({ company, people }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "lamina-equipo.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  async function importFile(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      const parsed = JSON.parse(await file.text()) as { company?: unknown; people?: unknown };
      const nextPeople = Array.isArray(parsed.people)
        ? parsed.people.map(sanitizePerson).filter((item): item is Person => item !== null).slice(0, 40)
        : [];
      const nextCompany = sanitizeCompany(parsed.company) ?? company;
      if (nextPeople.length === 0) {
        setError("Ese archivo no tiene personas válidas.");
        return;
      }
      replaceAll(nextCompany, nextPeople);
    } catch {
      setError("No se pudo leer el archivo. Tiene que ser el JSON exportado desde Lámina.");
    }
  }

  return (
    <div className="no-print fixed inset-0 z-40 flex justify-end bg-ink/40">
      <button type="button" aria-label="Cerrar editor" className="hidden flex-1 sm:block" onClick={onClose} />
      <aside className="flex h-full w-full max-w-md flex-col bg-surface text-ink shadow-2xl">
        <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
          <div>
            <h2 className="font-display text-2xl">Editar</h2>
            <p className="text-sm text-muted">Se guarda en este navegador.</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="inline-flex size-11 items-center justify-center rounded-full border border-line"
          >
            <X className="size-5" />
          </button>
        </header>
        <div className="flex flex-1 flex-col gap-6 overflow-y-auto px-4 py-5">
          <section className="flex flex-col gap-3">
            <h3 className="text-xs tracking-widest text-muted uppercase">Empresa</h3>
            <Field label="Título de arriba" value={company.mark} onChange={(mark) => setCompany({ mark })} />
            <Field label="Nombre" value={company.name} onChange={(name) => setCompany({ name })} />
            <Field label="Línea" value={company.line} onChange={(line) => setCompany({ line })} />
          </section>

          <section className="flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xs tracking-widest text-muted uppercase">Personas</h3>
              <button
                type="button"
                onClick={addPerson}
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm text-accent-ink"
              >
                <Plus className="size-4" aria-hidden="true" />
                Añadir
              </button>
            </div>
            <div className="flex items-center gap-2">
              <select
                aria-label="Elegir persona"
                value={person?.id ?? ""}
                onChange={(event) => {
                  setConfirmDelete(false);
                  select(event.target.value);
                }}
                className={fieldClass}
              >
                {people.length === 0 ? <option value="">Sin personas</option> : null}
                {people.map((item, index) => (
                  <option key={item.id} value={item.id}>
                    {String(index + 1).padStart(2, "0")} · {item.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                aria-label="Subir en el orden"
                disabled={!person}
                onClick={() => person && movePerson(person.id, -1)}
                className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line disabled:opacity-40"
              >
                <ChevronUp className="size-4" />
              </button>
              <button
                type="button"
                aria-label="Bajar en el orden"
                disabled={!person}
                onClick={() => person && movePerson(person.id, 1)}
                className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line disabled:opacity-40"
              >
                <ChevronDown className="size-4" />
              </button>
            </div>
          </section>

          {person ? (
            <section className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="size-20 overflow-hidden rounded-full">
                  <Portrait person={person} letterClassName="text-3xl" />
                </div>
                <div className="flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-4 text-sm"
                  >
                    <Upload className="size-4" aria-hidden="true" />
                    Subir foto
                  </button>
                  {person.photo ? (
                    <button
                      type="button"
                      onClick={() => patch((current) => ({ ...current, photo: "" }))}
                      className="text-left text-sm text-muted"
                    >
                      Quitar foto
                    </button>
                  ) : (
                    <p className="text-sm text-muted">Sin foto se muestra la inicial.</p>
                  )}
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={(event) => {
                    void onPhoto(event.target.files?.[0]);
                    event.target.value = "";
                  }}
                />
              </div>
              {error ? <p className="text-sm text-accent">{error}</p> : null}
              <Field label="Nombre de la persona" value={person.name} onChange={(name) => patch((p) => ({ ...p, name }))} />
              <Field label="Puesto" value={person.role} onChange={(role) => patch((p) => ({ ...p, role }))} />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Área" value={person.area} onChange={(area) => patch((p) => ({ ...p, area }))} />
                <Field label="Ciudad" value={person.city} onChange={(city) => patch((p) => ({ ...p, city }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Correo" value={person.email} onChange={(email) => patch((p) => ({ ...p, email }))} />
                <Field label="Teléfono" value={person.phone} onChange={(phone) => patch((p) => ({ ...p, phone }))} />
              </div>
              <Field label="En la empresa desde" value={person.since} onChange={(since) => patch((p) => ({ ...p, since }))} />
              <Field label="Biografía" value={person.bio} multiline onChange={(bio) => patch((p) => ({ ...p, bio }))} />
              <Field label="Frase" value={person.quote} onChange={(quote) => patch((p) => ({ ...p, quote }))} />

              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs tracking-widest text-muted uppercase">Datos del póster</h3>
                  <button
                    type="button"
                    disabled={person.stats.length >= 4}
                    onClick={() =>
                      patch((current) => ({
                        ...current,
                        stats: [...current.stats, { id: crypto.randomUUID(), label: "Dato", value: "—" }],
                      }))
                    }
                    className="min-h-11 text-sm text-accent disabled:opacity-40"
                  >
                    Añadir dato
                  </button>
                </div>
                {person.stats.map((stat) => (
                  <div key={stat.id} className="grid grid-cols-[1fr_5rem_auto] gap-2">
                    <input
                      aria-label="Etiqueta del dato"
                      value={stat.label}
                      onChange={(event) =>
                        patch((current) => ({
                          ...current,
                          stats: current.stats.map((item) =>
                            item.id === stat.id ? { ...item, label: event.target.value } : item,
                          ),
                        }))
                      }
                      className={fieldClass}
                    />
                    <input
                      aria-label="Valor del dato"
                      value={stat.value}
                      onChange={(event) =>
                        patch((current) => ({
                          ...current,
                          stats: current.stats.map((item) =>
                            item.id === stat.id ? { ...item, value: event.target.value } : item,
                          ),
                        }))
                      }
                      className={fieldClass}
                    />
                    <button
                      type="button"
                      aria-label="Quitar dato"
                      onClick={() =>
                        patch((current) => ({ ...current, stats: current.stats.filter((item) => item.id !== stat.id) }))
                      }
                      className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                    >
                      <X className="size-4" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs tracking-widest text-muted uppercase">Habilidades</h3>
                  <button
                    type="button"
                    disabled={person.skills.length >= 6}
                    onClick={() =>
                      patch((current) => ({
                        ...current,
                        skills: [...current.skills, { id: crypto.randomUUID(), name: "Habilidad", level: 3 }],
                      }))
                    }
                    className="min-h-11 text-sm text-accent disabled:opacity-40"
                  >
                    Añadir
                  </button>
                </div>
                {person.skills.map((skill) => (
                  <div key={skill.id} className="flex flex-col gap-2 rounded-xl border border-line p-3">
                    <div className="flex gap-2">
                      <input
                        aria-label="Nombre de la habilidad"
                        value={skill.name}
                        onChange={(event) =>
                          patch((current) => ({
                            ...current,
                            skills: current.skills.map((item) =>
                              item.id === skill.id ? { ...item, name: event.target.value } : item,
                            ),
                          }))
                        }
                        className={fieldClass}
                      />
                      <button
                        type="button"
                        aria-label="Quitar habilidad"
                        onClick={() =>
                          patch((current) => ({
                            ...current,
                            skills: current.skills.filter((item) => item.id !== skill.id),
                          }))
                        }
                        className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line"
                      >
                        <X className="size-4" />
                      </button>
                    </div>
                    <div className="flex gap-1" role="group" aria-label={`Nivel de ${skill.name}`}>
                      {[1, 2, 3, 4, 5].map((level) => (
                        <button
                          key={level}
                          type="button"
                          aria-pressed={skill.level === level}
                          onClick={() =>
                            patch((current) => ({
                              ...current,
                              skills: current.skills.map((item) => (item.id === skill.id ? { ...item, level } : item)),
                            }))
                          }
                          className={
                            level <= skill.level
                              ? "min-h-11 flex-1 rounded-lg bg-ink text-sm text-deep-fg"
                              : "min-h-11 flex-1 rounded-lg border border-line text-sm text-muted"
                          }
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs tracking-widest text-muted uppercase">Señales</h3>
                  <button
                    type="button"
                    disabled={person.highlights.length >= 5}
                    onClick={() => patch((current) => ({ ...current, highlights: [...current.highlights, ""] }))}
                    className="min-h-11 text-sm text-accent disabled:opacity-40"
                  >
                    Añadir
                  </button>
                </div>
                {person.highlights.map((highlight, index) => (
                  <div key={`${person.id}-h${index}`} className="flex gap-2">
                    <input
                      aria-label={`Señal ${index + 1}`}
                      value={highlight}
                      onChange={(event) =>
                        patch((current) => ({
                          ...current,
                          highlights: current.highlights.map((item, itemIndex) =>
                            itemIndex === index ? event.target.value : item,
                          ),
                        }))
                      }
                      className={fieldClass}
                    />
                    <button
                      type="button"
                      aria-label="Quitar señal"
                      onClick={() =>
                        patch((current) => ({
                          ...current,
                          highlights: current.highlights.filter((_, itemIndex) => itemIndex !== index),
                        }))
                      }
                      className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line"
                    >
                      <X className="size-4" />
                    </button>
                  </div>
                ))}
              </div>

              {confirmDelete ? (
                <div className="flex flex-col gap-2 rounded-xl border border-line bg-paper p-3">
                  <p className="text-sm">¿Eliminar a {person.name}?</p>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        removePerson(person.id);
                        setConfirmDelete(false);
                      }}
                      className="min-h-11 flex-1 rounded-full bg-accent text-sm text-accent-ink"
                    >
                      Eliminar
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(false)}
                      className="min-h-11 flex-1 rounded-full border border-line text-sm"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-line text-sm text-accent"
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                  Eliminar persona
                </button>
              )}
            </section>
          ) : (
            <p className="text-sm text-muted">Añade a alguien para empezar la ficha.</p>
          )}

          <section className="flex flex-col gap-2 border-t border-line pt-4">
            <h3 className="text-xs tracking-widest text-muted uppercase">Copia de seguridad</h3>
            <p className="text-sm text-muted">
              Exporta el equipo si vas a cambiar de navegador. La importación sustituye lo que hay ahora.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={exportFile}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm"
              >
                <Download className="size-4" aria-hidden="true" />
                Exportar
              </button>
              <button
                type="button"
                onClick={() => importRef.current?.click()}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-line text-sm"
              >
                <Upload className="size-4" aria-hidden="true" />
                Importar
              </button>
              <input
                ref={importRef}
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(event) => {
                  void importFile(event.target.files?.[0]);
                  event.target.value = "";
                }}
              />
            </div>
            {confirmReset ? (
              <div className="flex flex-col gap-2">
                <p className="text-sm">Esto borra tus cambios y vuelve al equipo de ejemplo de {SEED_COMPANY.name}.</p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      resetExamples();
                      setConfirmReset(false);
                    }}
                    className="min-h-11 flex-1 rounded-full bg-ink text-sm text-deep-fg"
                  >
                    Restaurar
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="min-h-11 flex-1 rounded-full border border-line text-sm"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            ) : (
              <button type="button" onClick={() => setConfirmReset(true)} className="min-h-11 text-left text-sm text-muted">
                Restaurar ejemplos
              </button>
            )}
          </section>
        </div>
      </aside>
    </div>
  );
}
