import { useEffect, useState } from "react";
import { cn } from "@/lib/cn";
import type { Person } from "@/lib/people";

export function Portrait({
  person,
  className,
  letterClassName,
}: {
  person: Person;
  className?: string;
  letterClassName?: string;
}) {
  const [broken, setBroken] = useState(false);
  useEffect(() => setBroken(false), [person.photo]);
  const letter = (person.name.trim().charAt(0) || "?").toUpperCase();

  if (person.photo && !broken) {
    return (
      <img
        src={person.photo}
        alt={person.name}
        className={cn("h-full w-full object-cover", className)}
        onError={() => setBroken(true)}
      />
    );
  }

  return (
    <div
      className={cn("flex h-full w-full items-center justify-center bg-deep text-deep-fg", className)}
      aria-hidden="true"
    >
      <span className={cn("font-display text-7xl italic leading-none", letterClassName)}>{letter}</span>
    </div>
  );
}

export function indexLabel(index: number, total: number) {
  return `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`;
}
