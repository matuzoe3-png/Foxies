import { useEffect } from "react";
import { BarChart3, LayoutGrid, Pencil, Presentation, Search, UserRound, X } from "lucide-react";
import { visiblePeople } from "@/lib/people";
import { useStudio, type StudioView } from "@/lib/studio-store";
import { Editor } from "@/components/studio/Editor";
import { Ficha, Infografia, Muro, Presentacion } from "@/components/studio/Views";

const VIEWS: { id: StudioView; label: string; icon: typeof LayoutGrid }[] = [
  { id: "muro", label: "Muro", icon: LayoutGrid },
  { id: "ficha", label: "Ficha", icon: UserRound },
  { id: "infografia", label: "Póster", icon: BarChart3 },
  { id: "presentacion", label: "Presentar", icon: Presentation },
];

export function StudioApp() {
  const company = useStudio((state) => state.company);
  const people = useStudio((state) => state.people);
  const selectedId = useStudio((state) => state.selectedId);
  const hintDismissed = useStudio((state) => state.hintDismissed);
  const view = useStudio((state) => state.view);
  const editing = useStudio((state) => state.editing);
  const query = useStudio((state) => state.query);
  const area = useStudio((state) => state.area);
  const setView = useStudio((state) => state.setView);
  const setEditing = useStudio((state) => state.setEditing);
  const setQuery = useStudio((state) => state.setQuery);
  const setArea = useStudio((state) => state.setArea);
  const select = useStudio((state) => state.select);
  const dismissHint = useStudio((state) => state.dismissHint);

  useEffect(() => {
    void useStudio.persist.rehydrate();
  }, []);

  const mark = company.mark.trim() || "Lámina";

  useEffect(() => {
    document.title = mark;
  }, [mark]);

  const areas = ["Todos", ...Array.from(new Set(people.map((person) => person.area).filter(Boolean)))];
  const activeArea = areas.includes(area) ? area : "Todos";
  const filtered = visiblePeople(people, query, activeArea);
  const deck = view === "presentacion" ? people : filtered;
  const person = deck.find((item) => item.id === selectedId) ?? deck[0];
  const index = person ? deck.findIndex((item) => item.id === person.id) : -1;

  function step(dir: -1 | 1) {
    if (deck.length === 0) return;
    const current = Math.max(0, index);
    const next = (current + dir + deck.length) % deck.length;
    select(deck[next].id);
  }

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      if (target instanceof HTMLElement) {
        const tag = target.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable) return;
      }
      if (view !== "presentacion" && view !== "ficha" && view !== "infografia") return;
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
      if (event.key === "Escape" && view === "presentacion") setView("muro");
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  if (view === "presentacion") {
    return (
      <Presentacion
        people={people}
        person={people.find((item) => item.id === selectedId) ?? people[0]}
        companyName={company.name}
        brand={mark}
        onStep={(dir) => {
          if (people.length === 0) return;
          const current = Math.max(
            0,
            people.findIndex((item) => item.id === selectedId),
          );
          const next = (current + dir + people.length) % people.length;
          select(people[next].id);
        }}
        onSelect={select}
        onExit={() => setView("muro")}
      />
    );
  }

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-paper">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <p className="font-display text-2xl leading-none">{mark}</p>
            <p className="truncate text-sm text-muted">
              {company.name}
              {company.line ? ` · ${company.line}` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setEditing(!editing)}
            className={
              editing
                ? "inline-flex min-h-11 items-center gap-2 rounded-full bg-ink px-4 text-sm text-deep-fg"
                : "inline-flex min-h-11 items-center gap-2 rounded-full bg-accent px-4 text-sm text-accent-ink"
            }
          >
            <Pencil className="size-4" aria-hidden="true" />
            {editing ? "Cerrar" : "Editar"}
          </button>
        </div>
        <div className="mx-auto flex w-full max-w-6xl gap-1 overflow-x-auto px-4 pb-3">
          {VIEWS.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                aria-pressed={active}
                className={
                  active
                    ? "inline-flex min-h-11 shrink-0 items-center justify-center gap-1.5 rounded-full bg-ink px-3 text-sm text-deep-fg"
                    : "inline-flex min-h-11 shrink-0 items-center justify-center gap-1.5 rounded-full px-3 text-sm text-muted"
                }
              >
                <Icon className="size-4 shrink-0" aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-6xl flex-col gap-5 px-4 py-5">
        {!hintDismissed ? (
          <div className="no-print flex items-start justify-between gap-3 rounded-xl border border-line bg-surface px-4 py-3">
            <p className="text-sm leading-relaxed">
              Estos seis perfiles son de ejemplo. Edita el nombre de tu empresa, cambia los datos, sube fotos o
              bórralos y crea los de tu equipo. Todo queda guardado en este navegador.
            </p>
            <button
              type="button"
              onClick={dismissHint}
              aria-label="Ocultar aviso"
              className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-line"
            >
              <X className="size-4" />
            </button>
          </div>
        ) : null}

        {view === "muro" ? (
          <div className="no-print flex flex-col gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Buscar por nombre, puesto o ciudad"
                aria-label="Buscar personas"
                className="min-h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-base outline-none"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {areas.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setArea(item)}
                  className={
                    activeArea === item
                      ? "min-h-11 shrink-0 rounded-full bg-ink px-4 text-sm text-deep-fg"
                      : "min-h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm"
                  }
                >
                  {item}
                </button>
              ))}
            </div>
            <p className="text-sm text-muted tabular-nums">
              {filtered.length} {filtered.length === 1 ? "persona" : "personas"}
            </p>
          </div>
        ) : null}

        {view === "muro" ? (
          <Muro
            people={filtered}
            onOpen={(id) => {
              select(id);
              setView("ficha");
            }}
          />
        ) : null}
        {view === "ficha" ? (
          <Ficha person={person} companyName={company.name} index={index} total={deck.length} onStep={step} />
        ) : null}
        {view === "infografia" ? (
          <Infografia
            person={person}
            companyName={company.name}
            brand={mark}
            index={index}
            total={deck.length}
            onStep={step}
          />
        ) : null}

        <p className="no-print pb-4 text-center text-xs text-muted">
          Los cambios viven en este navegador. En Editar puedes exportar una copia.
        </p>
      </main>
      {editing ? <Editor onClose={() => setEditing(false)} /> : null}
    </div>
  );
}
