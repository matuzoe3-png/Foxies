import { ChevronLeft, ChevronRight, Mail, MapPin, Phone, Printer } from "lucide-react";
import type { Person } from "@/lib/people";
import { indexLabel, Portrait } from "@/components/studio/Portrait";

function initialsRow(people: Person[], selectedId: string, onSelect: (id: string) => void) {
  return (
    <div className="flex flex-wrap justify-center gap-2">
      {people.map((person, index) => {
        const active = person.id === selectedId;
        return (
          <button
            key={person.id}
            type="button"
            onClick={() => onSelect(person.id)}
            aria-label={person.name}
            aria-current={active ? "true" : undefined}
            className={
              active
                ? "flex min-h-11 min-w-11 items-center justify-center rounded-full bg-accent px-3 text-sm text-accent-ink"
                : "flex min-h-11 min-w-11 items-center justify-center rounded-full border border-line bg-surface px-3 text-sm text-ink"
            }
          >
            {String(index + 1).padStart(2, "0")}
          </button>
        );
      })}
    </div>
  );
}

export function Muro({
  people,
  onOpen,
}: {
  people: Person[];
  onOpen: (id: string) => void;
}) {
  if (people.length === 0) {
    return (
      <p className="rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted">
        Nadie coincide con la búsqueda. Prueba otro nombre o área.
      </p>
    );
  }

  return (
    <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {people.map((person, index) => (
        <li key={person.id}>
          <button
            type="button"
            onClick={() => onOpen(person.id)}
            className="flex h-full w-full flex-col overflow-hidden rounded-card border border-line bg-surface text-left transition duration-200 hover:-translate-y-0.5"
          >
            <div className="relative aspect-4/5 overflow-hidden">
              <Portrait person={person} className="absolute inset-0" />
              <span className="absolute top-3 left-3 rounded-full bg-paper px-2.5 py-1 text-xs text-ink tabular-nums">
                {String(index + 1).padStart(2, "0")}
              </span>
            </div>
            <div className="flex flex-1 flex-col gap-1 p-4">
              <h2 className="font-display text-2xl leading-tight text-ink">{person.name}</h2>
              <p className="text-sm text-muted">{person.role}</p>
              <p className="mt-2 text-xs tracking-widest text-accent uppercase">{person.area}</p>
            </div>
          </button>
        </li>
      ))}
    </ul>
  );
}

function Contact({ person }: { person: Person }) {
  const items = [
    person.city ? { icon: MapPin, text: person.city } : null,
    person.email ? { icon: Mail, text: person.email } : null,
    person.phone ? { icon: Phone, text: person.phone } : null,
  ].filter((item): item is { icon: typeof MapPin; text: string } => item !== null);
  if (items.length === 0) return null;
  return (
    <ul className="flex flex-col gap-2 text-sm text-muted">
      {items.map((item) => (
        <li key={item.text} className="flex items-center gap-2">
          <item.icon className="size-4 shrink-0" aria-hidden="true" />
          <span className="break-all">{item.text}</span>
        </li>
      ))}
    </ul>
  );
}

function Stats({ person }: { person: Person }) {
  if (person.stats.length === 0) return null;
  return (
    <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-4">
      {person.stats.map((stat) => (
        <div key={stat.id} className="bg-paper px-3 py-4">
          <dt className="text-xs tracking-widest text-muted uppercase">{stat.label}</dt>
          <dd className="font-display text-3xl text-ink tabular-nums">{stat.value}</dd>
        </div>
      ))}
    </dl>
  );
}

function Skills({ person }: { person: Person }) {
  if (person.skills.length === 0) return null;
  return (
    <ul className="flex flex-col gap-3">
      {person.skills.map((skill) => (
        <li key={skill.id}>
          <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
            <span>{skill.name}</span>
            <span className="text-muted tabular-nums">{skill.level}/5</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-line" aria-hidden="true">
            <div className="h-full rounded-full bg-ink" style={{ width: `${(skill.level / 5) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

function Highlights({ person }: { person: Person }) {
  const items = person.highlights.filter((item) => item.trim());
  if (items.length === 0) return null;
  return (
    <ol className="flex flex-col gap-2">
      {items.map((item, index) => (
        <li key={`${item}-${index}`} className="flex gap-3 text-sm">
          <span className="font-display text-accent tabular-nums">{String(index + 1).padStart(2, "0")}</span>
          <span>{item}</span>
        </li>
      ))}
    </ol>
  );
}

function SheetNav({
  index,
  total,
  onStep,
}: {
  index: number;
  total: number;
  onStep: (dir: -1 | 1) => void;
}) {
  return (
    <div className="no-print flex items-center justify-between gap-3">
      <button
        type="button"
        onClick={() => onStep(-1)}
        className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm"
      >
        <ChevronLeft className="size-4" aria-hidden="true" />
        Anterior
      </button>
      <p className="text-sm text-muted tabular-nums">{index >= 0 ? indexLabel(index, total) : "—"}</p>
      <button
        type="button"
        onClick={() => onStep(1)}
        className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm"
      >
        Siguiente
        <ChevronRight className="size-4" aria-hidden="true" />
      </button>
    </div>
  );
}

export function Ficha({
  person,
  companyName,
  index,
  total,
  onStep,
}: {
  person: Person | undefined;
  companyName: string;
  index: number;
  total: number;
  onStep: (dir: -1 | 1) => void;
}) {
  if (!person) {
    return (
      <p className="rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted">
        No hay nadie en esta vista. Añade una persona o limpia el filtro.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <article className="print-sheet overflow-hidden rounded-card border border-line bg-surface md:grid md:grid-cols-[minmax(0,0.86fr)_minmax(0,1.14fr)]">
        <div className="relative min-h-80">
          <Portrait person={person} className="absolute inset-0" letterClassName="text-8xl md:text-9xl" />
        </div>
        <div className="flex flex-col gap-6 p-6 md:p-10">
          <div className="flex items-start justify-between gap-3">
            <p className="text-xs tracking-widest text-accent uppercase">{companyName}</p>
            <button
              type="button"
              onClick={() => window.print()}
              className="no-print inline-flex min-h-11 items-center gap-2 text-sm text-muted"
            >
              <Printer className="size-4" aria-hidden="true" />
              Imprimir
            </button>
          </div>
          <div>
            <p className="text-xs tracking-widest text-muted uppercase">{person.area}</p>
            <h2 className="font-display text-5xl leading-none text-ink">{person.name}</h2>
            <p className="mt-2 text-lg text-muted">
              {person.role}
              {person.since ? ` · desde ${person.since}` : ""}
            </p>
          </div>
          {person.bio ? <p className="max-w-prose text-base leading-relaxed">{person.bio}</p> : null}
          {person.quote ? (
            <blockquote className="border-l-2 border-accent pl-4 font-display text-2xl italic leading-snug">
              {person.quote}
            </blockquote>
          ) : null}
          <Stats person={person} />
          <Contact person={person} />
        </div>
      </article>
      <SheetNav index={index} total={total} onStep={onStep} />
    </div>
  );
}

export function Infografia({
  person,
  companyName,
  brand,
  index,
  total,
  onStep,
}: {
  person: Person | undefined;
  companyName: string;
  brand: string;
  index: number;
  total: number;
  onStep: (dir: -1 | 1) => void;
}) {
  if (!person) {
    return (
      <p className="rounded-card border border-dashed border-line bg-surface px-6 py-16 text-center text-muted">
        No hay nadie para componer el póster.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <article className="print-sheet overflow-hidden rounded-card border border-line bg-surface">
        <div className="flex">
          <div className="w-2 shrink-0 bg-accent" aria-hidden="true" />
          <div className="flex min-w-0 flex-1 flex-col gap-8 p-5 sm:p-8 md:p-10">
            <div className="flex items-center justify-between gap-3 text-xs tracking-widest uppercase">
              <p className="text-muted">{companyName}</p>
              <p className="text-ink tabular-nums">{index >= 0 ? indexLabel(index, total) : ""}</p>
            </div>
            <div className="grid items-start gap-8 md:grid-cols-5">
              <div className="order-2 flex flex-col gap-6 md:order-1 md:col-span-3">
                <div>
                  <p className="text-xs tracking-widest text-accent uppercase">{person.area}</p>
                  <h2 className="font-display text-5xl leading-none text-ink sm:text-6xl">{person.name}</h2>
                  <p className="mt-3 text-lg text-muted">{person.role}</p>
                </div>
                {person.bio ? <p className="max-w-prose leading-relaxed">{person.bio}</p> : null}
                <Stats person={person} />
              </div>
              <div className="order-1 md:order-2 md:col-span-2">
                <div className="aspect-square overflow-hidden rounded-card">
                  <Portrait person={person} letterClassName="text-8xl" />
                </div>
                <div className="mt-4">
                  <Contact person={person} />
                </div>
              </div>
            </div>
            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <h3 className="mb-3 text-xs tracking-widest text-muted uppercase">Oficio</h3>
                <Skills person={person} />
              </div>
              <div>
                <h3 className="mb-3 text-xs tracking-widest text-muted uppercase">Señales</h3>
                <Highlights person={person} />
              </div>
            </div>
            {person.quote ? (
              <blockquote className="font-display text-3xl italic leading-snug text-ink">“{person.quote}”</blockquote>
            ) : null}
            <div className="flex items-center justify-between gap-3 border-t border-line pt-4 text-xs tracking-widest text-muted uppercase">
              <span>{brand}</span>
              <button
                type="button"
                onClick={() => window.print()}
                className="no-print inline-flex min-h-11 items-center gap-2 normal-case"
              >
                <Printer className="size-4" aria-hidden="true" />
                Imprimir póster
              </button>
            </div>
          </div>
        </div>
      </article>
      <SheetNav index={index} total={total} onStep={onStep} />
    </div>
  );
}

export function Presentacion({
  people,
  person,
  companyName,
  brand,
  onStep,
  onSelect,
  onExit,
}: {
  people: Person[];
  person: Person | undefined;
  companyName: string;
  brand: string;
  onStep: (dir: -1 | 1) => void;
  onSelect: (id: string) => void;
  onExit: () => void;
}) {
  if (!person) {
    return (
      <div className="fixed inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-deep px-6 text-center text-deep-fg">
        <p>No hay personas para presentar.</p>
        <button type="button" onClick={onExit} className="min-h-11 rounded-full bg-accent px-5 text-accent-ink">
          Volver
        </button>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-30 flex flex-col bg-deep text-deep-fg"
      onTouchStart={(event) => {
        event.currentTarget.dataset.x = String(event.changedTouches[0]?.clientX ?? 0);
      }}
      onTouchEnd={(event) => {
        const start = Number(event.currentTarget.dataset.x || 0);
        const dx = (event.changedTouches[0]?.clientX ?? 0) - start;
        if (dx > 48) onStep(-1);
        if (dx < -48) onStep(1);
      }}
    >
      <header className="flex items-center justify-between gap-3 px-4 py-3 sm:px-8">
        <p className="font-display text-xl">{brand}</p>
        <p className="truncate text-sm text-deep-muted">{companyName}</p>
        <button
          type="button"
          onClick={onExit}
          className="min-h-11 rounded-full border border-deep-muted px-4 text-sm text-deep-fg"
        >
          Salir
        </button>
      </header>
      <div className="flex flex-1 flex-col items-center justify-center gap-8 overflow-y-auto px-5 py-6 md:flex-row md:gap-16 md:px-16">
        <div className="size-56 shrink-0 overflow-hidden rounded-full sm:size-72 md:size-96">
          <Portrait person={person} letterClassName="text-8xl" />
        </div>
        <div className="w-full max-w-xl text-center md:text-left">
          <p className="text-xs tracking-widest text-accent uppercase">{person.area}</p>
          <h1 className="font-display text-5xl leading-none sm:text-6xl md:text-7xl">{person.name}</h1>
          <p className="mt-3 text-xl text-deep-muted">{person.role}</p>
          {person.quote ? (
            <p className="mt-6 font-display text-2xl italic leading-snug text-deep-fg">{person.quote}</p>
          ) : null}
          {person.stats.length > 0 ? (
            <dl className="mt-8 grid grid-cols-3 gap-4">
              {person.stats.slice(0, 3).map((stat) => (
                <div key={stat.id}>
                  <dt className="text-xs tracking-widest text-deep-muted uppercase">{stat.label}</dt>
                  <dd className="font-display text-3xl tabular-nums">{stat.value}</dd>
                </div>
              ))}
            </dl>
          ) : null}
        </div>
      </div>
      <footer className="flex flex-col items-center gap-4 px-4 pt-2 pb-6">
        {initialsRow(people, person.id, onSelect)}
        <div className="flex items-center gap-3">
          <button
            type="button"
            aria-label="Persona anterior"
            onClick={() => onStep(-1)}
            className="inline-flex size-11 items-center justify-center rounded-full border border-deep-muted"
          >
            <ChevronLeft className="size-5" />
          </button>
          <button
            type="button"
            aria-label="Persona siguiente"
            onClick={() => onStep(1)}
            className="inline-flex size-11 items-center justify-center rounded-full bg-accent text-accent-ink"
          >
            <ChevronRight className="size-5" />
          </button>
        </div>
      </footer>
    </div>
  );
}
