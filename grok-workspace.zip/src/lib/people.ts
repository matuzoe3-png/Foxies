export type Stat = { id: string; label: string; value: string };
export type Skill = { id: string; name: string; level: number };

export type Person = {
  id: string;
  name: string;
  role: string;
  area: string;
  city: string;
  email: string;
  phone: string;
  since: string;
  bio: string;
  quote: string;
  photo: string;
  stats: Stat[];
  skills: Skill[];
  highlights: string[];
};

export type Company = {
  name: string;
  line: string;
  mark: string;
};

export const SEED_COMPANY: Company = {
  name: "Tu empresa",
  line: "Equipo y personas",
  mark: "Lámina",
};

function person(
  id: string,
  data: Omit<Person, "id" | "photo" | "stats" | "skills" | "highlights"> & {
    stats: [string, string][];
    skills: [string, number][];
    highlights: string[];
  },
): Person {
  return {
    id,
    name: data.name,
    role: data.role,
    area: data.area,
    city: data.city,
    email: data.email,
    phone: data.phone,
    since: data.since,
    bio: data.bio,
    quote: data.quote,
    photo: "",
    stats: data.stats.map(([label, value], i) => ({ id: `${id}-st${i}`, label, value })),
    skills: data.skills.map(([name, level], i) => ({ id: `${id}-sk${i}`, name, level })),
    highlights: data.highlights,
  };
}

export const SEED_PEOPLE: Person[] = [
  person("marina", {
    name: "Marina Soler",
    role: "Directora general",
    area: "Dirección",
    city: "Madrid",
    email: "marina@tuempresa.com",
    phone: "+34 600 110 201",
    since: "2016",
    bio: "Marca el rumbo del estudio y cuida la relación con las cuentas que definen el año. Viene de dos agencias de marca y prefiere las decisiones escritas a las reuniones largas.",
    quote: "Si no cabe en una ficha, todavía no está claro.",
    stats: [
      ["Años", "10"],
      ["Cuentas", "48"],
      ["Equipo", "22"],
      ["Sedes", "3"],
    ],
    skills: [
      ["Estrategia", 5],
      ["Cuentas", 4],
      ["Negociación", 4],
    ],
    highlights: [
      "Abrió la oficina de Madrid",
      "Mentora del equipo junior",
      "Lleva el comité de clientes",
    ],
  }),
  person("hugo", {
    name: "Hugo Beltrán",
    role: "Director de diseño",
    area: "Diseño",
    city: "Barcelona",
    email: "hugo@tuempresa.com",
    phone: "+34 600 110 202",
    since: "2018",
    bio: "Traduce el brief en un sistema visual que el resto del equipo puede usar sin preguntar. Obsesionado con el ritmo tipográfico y con que cada entrega se entienda impresa.",
    quote: "Una buena lámina ahorra tres correos.",
    stats: [
      ["Piezas", "120"],
      ["Premios", "6"],
      ["Sistemas", "9"],
      ["Años", "8"],
    ],
    skills: [
      ["Dirección de arte", 5],
      ["Tipografía", 5],
      ["Identidad", 4],
    ],
    highlights: ["Autor del sistema visual actual", "Revisa cada póster antes de salir"],
  }),
  person("ines", {
    name: "Inés Calderón",
    role: "Jefa de operaciones",
    area: "Operaciones",
    city: "Valencia",
    email: "ines@tuempresa.com",
    phone: "+34 600 110 203",
    since: "2019",
    bio: "Hace que los plazos se cumplan sin apagar al equipo. Coordina producción, proveedores y el calendario de entregas de las tres sedes.",
    quote: "El orden también es una forma de cuidar.",
    stats: [
      ["Proyectos", "64"],
      ["A tiempo", "96%"],
      ["Proveedores", "18"],
      ["Años", "7"],
    ],
    skills: [
      ["Planificación", 5],
      ["Proveedores", 4],
      ["Procesos", 4],
    ],
    highlights: ["Dueña del calendario semanal", "Montó el protocolo de entregas"],
  }),
  person("leo", {
    name: "Leo Navarro",
    role: "Comercial senior",
    area: "Comercial",
    city: "Sevilla",
    email: "leo@tuempresa.com",
    phone: "+34 600 110 204",
    since: "2020",
    bio: "Abre conversaciones y las deja en un brief que diseño puede ejecutar. Conoce el sector hotelero y el de alimentación mejor que nadie en la casa.",
    quote: "Vendo la claridad, no el PowerPoint.",
    stats: [
      ["Pipeline", "1.2M"],
      ["Cierres", "17"],
      ["Sectores", "4"],
      ["Años", "6"],
    ],
    skills: [
      ["Nuevo negocio", 5],
      ["Briefs", 4],
      ["Cuentas", 4],
    ],
    highlights: ["Mayor cuenta del año pasado", "Enlace con hostelería"],
  }),
  person("amina", {
    name: "Amina Farouk",
    role: "Product manager",
    area: "Producto",
    city: "Málaga",
    email: "amina@tuempresa.com",
    phone: "+34 600 110 205",
    since: "2021",
    bio: "Ordena qué se construye y por qué. Trabaja entre diseño, comercial y el cliente para que la pieza digital no se despegue de la promesa.",
    quote: "Una prioridad clara vale más que diez ideas.",
    stats: [
      ["Lanzamientos", "11"],
      ["NPS", "72"],
      ["Squads", "2"],
      ["Años", "5"],
    ],
    skills: [
      ["Discovery", 5],
      ["Roadmap", 4],
      ["Research", 4],
    ],
    highlights: ["Lanzó el portal de clientes", "Facilita la revisión quincenal"],
  }),
  person("tomas", {
    name: "Tomás Riera",
    role: "Responsable financiero",
    area: "Finanzas",
    city: "Bilbao",
    email: "tomas@tuempresa.com",
    phone: "+34 600 110 206",
    since: "2017",
    bio: "Cuida el margen sin convertir cada proyecto en una hoja imposible. Explica los números en el mismo idioma que usa el resto del estudio.",
    quote: "Un número solo sirve si alguien puede contarlo.",
    stats: [
      ["Margen", "28%"],
      ["Cierres", "9"],
      ["Años", "9"],
      ["Auditorías", "4"],
    ],
    skills: [
      ["Control", 5],
      ["Previsión", 4],
      ["Contratos", 3],
    ],
    highlights: ["Cierre mensual en cinco días", "Modelo de rentabilidad por cuenta"],
  }),
];

export function uid(): string {
  return crypto.randomUUID();
}

export function blankPerson(): Person {
  const id = uid();
  return {
    id,
    name: "Nueva persona",
    role: "Puesto",
    area: "Equipo",
    city: "",
    email: "",
    phone: "",
    since: "",
    bio: "",
    quote: "",
    photo: "",
    stats: [
      { id: uid(), label: "Años", value: "—" },
      { id: uid(), label: "Proyectos", value: "—" },
      { id: uid(), label: "Equipo", value: "—" },
    ],
    skills: [{ id: uid(), name: "Habilidad", level: 3 }],
    highlights: [],
  };
}

function clip(value: unknown, max: number, fallback = ""): string {
  if (typeof value !== "string") return fallback;
  return value.slice(0, max);
}

export function sanitizePerson(raw: unknown): Person | null {
  if (!raw || typeof raw !== "object") return null;
  const row = raw as Record<string, unknown>;
  const id = clip(row.id, 80);
  const name = clip(row.name, 120);
  if (!id || !name) return null;
  const statsRaw = Array.isArray(row.stats) ? row.stats : [];
  const skillsRaw = Array.isArray(row.skills) ? row.skills : [];
  const highlightsRaw = Array.isArray(row.highlights) ? row.highlights : [];
  const photo = clip(row.photo, 600_000);
  const safePhoto = photo.startsWith("data:image/") ? photo : "";
  return {
    id,
    name,
    role: clip(row.role, 120),
    area: clip(row.area, 80),
    city: clip(row.city, 80),
    email: clip(row.email, 160),
    phone: clip(row.phone, 40),
    since: clip(row.since, 40),
    bio: clip(row.bio, 1200),
    quote: clip(row.quote, 280),
    photo: safePhoto,
    stats: statsRaw.slice(0, 6).flatMap((item, i) => {
      if (!item || typeof item !== "object") return [];
      const stat = item as Record<string, unknown>;
      const label = clip(stat.label, 40);
      const value = clip(stat.value, 24);
      if (!label && !value) return [];
      return [{ id: clip(stat.id, 80) || `${id}-st${i}`, label: label || "Dato", value: value || "—" }];
    }),
    skills: skillsRaw.slice(0, 8).flatMap((item, i) => {
      if (!item || typeof item !== "object") return [];
      const skill = item as Record<string, unknown>;
      const skillName = clip(skill.name, 40);
      if (!skillName) return [];
      const level = typeof skill.level === "number" ? Math.min(5, Math.max(1, Math.round(skill.level))) : 3;
      return [{ id: clip(skill.id, 80) || `${id}-sk${i}`, name: skillName, level }];
    }),
    highlights: highlightsRaw
      .filter((item): item is string => typeof item === "string")
      .map((item) => item.slice(0, 160))
      .filter((item) => item.trim().length > 0)
      .slice(0, 6),
  };
}

export function sanitizeCompany(raw: unknown): Company | null {
  if (!raw || typeof raw !== "object") return null;
  const row = raw as Record<string, unknown>;
  const name = clip(row.name, 80);
  if (!name) return null;
  return {
    name,
    line: clip(row.line, 120, SEED_COMPANY.line),
    mark: clip(row.mark, 40, SEED_COMPANY.mark) || SEED_COMPANY.mark,
  };
}

export function visiblePeople(people: Person[], query: string, area: string): Person[] {
  const q = query.trim().toLowerCase();
  return people.filter((person) => {
    if (area && area !== "Todos" && person.area !== area) return false;
    if (!q) return true;
    const hay = [person.name, person.role, person.area, person.city, person.bio, person.quote]
      .join(" ")
      .toLowerCase();
    return hay.includes(q);
  });
}

export function compressPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("No se pudo leer la foto."));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 720;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("No se pudo preparar la foto."));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      };
      img.onerror = () => reject(new Error("Usa una foto JPG o PNG."));
      img.src = String(reader.result || "");
    };
    reader.readAsDataURL(file);
  });
}
