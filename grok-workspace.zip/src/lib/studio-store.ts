import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  SEED_COMPANY,
  SEED_PEOPLE,
  blankPerson,
  sanitizeCompany,
  sanitizePerson,
  type Company,
  type Person,
} from "@/lib/people";

export type StudioView = "muro" | "ficha" | "infografia" | "presentacion";

type Persisted = {
  company?: Company;
  people?: Person[];
  selectedId?: string;
  hintDismissed?: boolean;
};

type Studio = {
  company: Company;
  people: Person[];
  selectedId: string;
  hintDismissed: boolean;
  view: StudioView;
  editing: boolean;
  query: string;
  area: string;
  setView: (view: StudioView) => void;
  setEditing: (editing: boolean) => void;
  setQuery: (query: string) => void;
  setArea: (area: string) => void;
  select: (id: string) => void;
  dismissHint: () => void;
  setCompany: (patch: Partial<Company>) => void;
  updatePerson: (id: string, recipe: (person: Person) => Person) => void;
  addPerson: () => void;
  removePerson: (id: string) => void;
  movePerson: (id: string, dir: -1 | 1) => void;
  replaceAll: (company: Company, people: Person[]) => void;
  resetExamples: () => void;
};

function seedState() {
  return {
    company: SEED_COMPANY,
    people: SEED_PEOPLE,
    selectedId: SEED_PEOPLE[0].id,
    hintDismissed: false,
  };
}

export const useStudio = create<Studio>()(
  persist(
    (set) => ({
      ...seedState(),
      view: "muro",
      editing: false,
      query: "",
      area: "Todos",
      setView: (view) =>
        set((state) => ({
          view,
          editing: view === "presentacion" ? false : state.editing,
        })),
      setEditing: (editing) => set({ editing }),
      setQuery: (query) => set({ query }),
      setArea: (area) => set({ area }),
      select: (id) => set({ selectedId: id }),
      dismissHint: () => set({ hintDismissed: true }),
      setCompany: (patch) => set((state) => ({ company: { ...state.company, ...patch } })),
      updatePerson: (id, recipe) =>
        set((state) => ({
          people: state.people.map((person) => (person.id === id ? recipe(person) : person)),
        })),
      addPerson: () => {
        const person = blankPerson();
        set((state) => ({
          people: [...state.people, person],
          selectedId: person.id,
          editing: true,
          view: state.view === "presentacion" ? "ficha" : state.view,
        }));
      },
      removePerson: (id) =>
        set((state) => {
          const people = state.people.filter((person) => person.id !== id);
          return {
            people,
            selectedId: state.selectedId === id ? (people[0]?.id ?? "") : state.selectedId,
          };
        }),
      movePerson: (id, dir) =>
        set((state) => {
          const index = state.people.findIndex((person) => person.id === id);
          const next = index + dir;
          if (index < 0 || next < 0 || next >= state.people.length) return state;
          const people = state.people.slice();
          const [item] = people.splice(index, 1);
          people.splice(next, 0, item);
          return { people };
        }),
      replaceAll: (company, people) =>
        set({
          company,
          people,
          selectedId: people[0]?.id ?? "",
          editing: true,
          view: "muro",
        }),
      resetExamples: () => set({ ...seedState(), view: "muro", editing: true, query: "", area: "Todos" }),
    }),
    {
      name: "lamina-v1",
      skipHydration: true,
      partialize: (state) => ({
        company: state.company,
        people: state.people,
        selectedId: state.selectedId,
        hintDismissed: state.hintDismissed,
      }),
      merge: (persisted, current) => {
        const data = (persisted ?? {}) as Persisted;
        const people = Array.isArray(data.people)
          ? data.people.map(sanitizePerson).filter((person): person is Person => person !== null).slice(0, 40)
          : [];
        if (people.length === 0) return current;
        const company = sanitizeCompany(data.company) ?? current.company;
        const selectedId = people.some((person) => person.id === data.selectedId)
          ? (data.selectedId as string)
          : people[0].id;
        return {
          ...current,
          company,
          people,
          selectedId,
          hintDismissed: Boolean(data.hintDismissed),
        };
      },
    },
  ),
);
